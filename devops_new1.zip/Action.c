//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	truclient_step("1", "Navigate to 'http://advantageonlineshopping.com/'", "snapshot=Action_1.inf");
	truclient_step("2", "Click on HEADPHONES Shop Now", "snapshot=Action_2.inf");
	truclient_step("3", "Click on Beats Studio 2 Over Ear...", "snapshot=Action_3.inf");
	truclient_step("4", "Click on ADD TO CART button", "snapshot=Action_4.inf");
	truclient_step("5", "Click on CHECKOUT ($179.99) button", "snapshot=Action_5.inf");

	return 0;
}
